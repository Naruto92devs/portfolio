import React from "react";
import '../../index.css';
import WorkExperince from "../../Components/AboutpageComponents/WorkExperience";
import WhyHire from "../../Components/AboutpageComponents/WhyHire";


const About = () => {

    return (
        <div id="about" className="about">
            <WorkExperince/>
            <WhyHire/>
        </div>
    );
}

export default About;
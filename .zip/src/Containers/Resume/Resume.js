import React from "react";
import '../../index.css';
import DownloadPDF from './DownloadPDF';


const Resume = () => {

    return (
        <div className="resume">
            <div>
            <h2>
                <span className="span1">To Download </span>
                <span>My <br/> Resume</span>
            </h2>
            <DownloadPDF />
            </div>
            <div>
            <h2><span>Or Contact on</span> <span className="span1"> <br/> Whatsapp</span></h2>
            <a className="btn1" href="https://wa.me/923203655413">+923203655413</a>
            </div>
        </div>
    );
}

export default Resume;
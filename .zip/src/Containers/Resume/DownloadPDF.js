import React from 'react';
import pdfFile from '../../Components/Images/resume.pdf';

const DownloadPDF = () => {
  return (
    <div>
      <a className='btn1' href={pdfFile} download="document.pdf">
        Click Here....
      </a>
    </div>
  );
};

export default DownloadPDF;

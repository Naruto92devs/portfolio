import React from "react";
import '../../index.css';
import Slideimage from '../Images/slide-img.png';
import arrow from '../Images/arrow up right.svg';
import nugget1 from '../Images/nugget1.png';
import nugget2 from '../Images/nugget2.png';
import nugget3 from '../Images/nugget3.png';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css/bundle';
import { Pagination } from 'swiper/modules';
import './Services.css';


const Services = () => {

    const serivesettings = {
        breakpoints: {
          0: {
            slidesPerView: 1,
            spaceBetween:80, // 2 slides per view on screens >= 0px
          },
          300: {
            slidesPerView: 1.3,
            spaceBetween:25, // 2 slides per view on screens >= 300px
          },
          600: {
            slidesPerView: 2,
            spaceBetween:25, // 2 slides per view on screens >= 300px
          },
          980: {
            slidesPerView: 3,
            spaceBetween:50, // 3 slides per view on screens >= 980px
          },
          1600: {
            slidesPerView: 4,
            spaceBetween:50, // 3 slides per view on screens >= 1600px
          },
        },
      };

    return (
        <div className="services" id="services">
            <img className="nugget1" src={nugget1} alt="logo"/>
            <img className="nugget2" src={nugget2} alt="logo"/>
            <img className="nugget3" src={nugget3} alt="logo"/>
            <div className="heading">
                <h2>My <span>Services</span></h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis lacus nunc, posuere in justo vulputate, bibendum sodales</p>
            </div>
            <Swiper
            {...serivesettings}
            // spaceBetween={80}
            loop={true}
            pagination={{
            clickable: true,
            }}
            modules={[Pagination]}
            className="mySwiper"
            >
                <SwiperSlide>
                    <div className="heading">
                        <h3>UI/ UX Design1</h3>
                    </div>
                    <div className="fake">

                    </div>
                    <img className="service-img" src={Slideimage} alt="logo"/>
                    <img className="arrow" src={arrow} alt="logo"/>
                </SwiperSlide>
                <SwiperSlide>
                    <div className="heading">
                        <h3>UI/ UX Design2</h3>
                    </div>
                    <div className="fake">

                    </div>
                    <img className="service-img" src={Slideimage} alt="logo"/>
                    <img className="arrow" src={arrow} alt="logo"/>
                </SwiperSlide>
                <SwiperSlide>
                    <div className="heading">
                        <h3>UI/ UX Design3</h3>
                    </div>
                    <div className="fake">

                    </div>
                    <img className="service-img" src={Slideimage} alt="logo"/>
                    <img className="arrow" src={arrow} alt="logo"/>
                </SwiperSlide>
                <SwiperSlide>
                    <div className="heading">
                        <h3>UI/ UX Design4</h3>
                    </div>
                    <div className="fake">

                    </div>
                    <img className="service-img" src={Slideimage} alt="logo"/>
                    <img className="arrow" src={arrow} alt="logo"/>
                </SwiperSlide>
                <SwiperSlide>
                    <div className="heading">
                        <h3>UI/ UX Design5</h3>
                    </div>
                    <div className="fake">

                    </div>
                    <img className="service-img" src={Slideimage} alt="logo"/>
                    <img className="arrow" src={arrow} alt="logo"/>
                </SwiperSlide>
                <SwiperSlide>
                    <div className="heading">
                        <h3>UI/ UX Design6</h3>
                    </div>
                    <div className="fake">

                    </div>
                    <img className="service-img" src={Slideimage} alt="logo"/>
                    <img className="arrow" src={arrow} alt="logo"/>
                </SwiperSlide>
                
                
            </Swiper>
        </div>
    );
}

export default Services;